'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var IntervalSchema = new Schema({
  startTime: {
    type: String
  },
  endTime: {
    type: String
  },
  season: {
    type: String
  },
  period: {
    type: String
  }
});

module.exports = mongoose.model('Interval', Intervalchema);
