'use strict';

var mongoose = require('mongoose'), Interval = mongoose.model('Intervals');

exports.find_interval = function(req, res) {
  Interval.find({}, function(err, interval) {
    if (err) res.send(err);
    res.json(interval);
  });
};
