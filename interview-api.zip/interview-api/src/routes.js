'use strict';

module.exports = function(app) {
  var interval = require('./controllers/data');

  app
    .route(
      '/api/tou/changes?startTime=2017-04-03T00:00:00.000Z&endTime=2017-04-03T00:17:00.000Z'
    )
    .post(interval.find_interval);
};
