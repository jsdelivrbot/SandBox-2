# Instructions

## First install packages with

* yarn

## Next, to run the app enter

* yarn start